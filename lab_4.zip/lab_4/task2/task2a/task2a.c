#include "util.h"

#define SYS_OPEN 5
#define SYS_CLOSE 6
#define SYS_READ 3
#define SYS_WRITE 4
#define SYS_EXIT 1
#define SYS_LSEEK 19
#define SYS_GETDENTS 141
#define STDIN 0
#define STDOUT 1
#define STDERR 2
#define BUF_SIZE 8192

typedef struct dirent {
    int inode;
    int offset;
    short len;
    char buf[];
} dirent;


int main(int argc, char **argv) {
    
    int debug_mode = 0, i;
    int filedesc;
    char* str;
    char inbuf[BUF_SIZE];
    dirent *direntp = inbuf;
    int count;
    int pos = 0;
    char* recName; 
    int write;
    
    for(i=1; i<argc; i++)
    {
        if(argv[i][1] == 'D') debug_mode = 1;
    }
    
    filedesc = system_call(SYS_OPEN, ".", 0, 0777);
    
    if(debug_mode)
    {
        system_call(SYS_WRITE, STDERR, "system_call:\nID: 5, return code: ", 33);
        str = itoa(filedesc);
        system_call(SYS_WRITE, STDERR, str, strlen(str));
        system_call(SYS_WRITE, STDERR, "\n", 1);
    }
    
    if(filedesc == -1)
    {
        system_call(SYS_WRITE, STDERR,"Error opening current directory. exit program.\n", 47);
        system_call(SYS_EXIT, 0x55);
    }
    
    count = system_call(SYS_GETDENTS, filedesc,inbuf, 8192);
    
    if(debug_mode)
    {
        system_call(SYS_WRITE, STDERR, "system_call:\nID: 141, return code: ", 33);
        str = itoa(count);
        system_call(SYS_WRITE, STDERR, str, strlen(str));
        system_call(SYS_WRITE, STDERR, "\n", 1);
    }
    
    if(count == -1)
    {
        system_call(SYS_WRITE, STDERR,"Error reading directory data. exit program.\n", 44);
        system_call(SYS_EXIT, 0x55);
    }
    
    if(count == 0)
    {
        system_call(SYS_WRITE, STDERR,"Current directory is empty. exit program.\n", 42);
        system_call(SYS_EXIT, 0);
    }
    
    write = system_call(SYS_WRITE, STDOUT,"Listing all file names in current directory:\n", 45);
    
    if(debug_mode)
    {
        system_call(SYS_WRITE, STDERR, "system_call:\nID: 4, return code: ", 33);
        str = itoa(write);
        system_call(SYS_WRITE, STDERR, str, strlen(str));
        system_call(SYS_WRITE, STDERR, "\n", 1);
    }

    
    while(pos < count) /* if count != 0 */
    {                        
        direntp = (dirent*)(inbuf + pos);
        
        if(direntp->len == 0) break;

        recName = direntp->buf;
        
        if(debug_mode) /* prints length and name of each dirent record */
        {
        system_call(SYS_WRITE, STDERR, "dirent_record:\nname: ", 21);
        system_call(SYS_WRITE, STDOUT, recName, strlen(recName));
        system_call(SYS_WRITE, STDERR, ", size: ", 7);
        str = itoa(direntp->len);
        system_call(SYS_WRITE, STDERR, str, strlen(str));
        system_call(SYS_WRITE, STDERR, "\n", 1);
        }
        
        /* skip over curr_dir, parent_dir and all hidden files */
        if(direntp->buf[0] == '.')
        {
            pos = pos + direntp->len;
            continue;
        }
                
        write = system_call(SYS_WRITE, STDOUT, recName, strlen(recName));
        
        system_call(SYS_WRITE, STDOUT, "\n", 1);
        
        if(debug_mode)
        {
        system_call(SYS_WRITE, STDERR, "system_call:\nID: 4, return code: ", 33);
        str = itoa(write);
        system_call(SYS_WRITE, STDERR, str, strlen(str));
        system_call(SYS_WRITE, STDERR, "\n", 1);
        }
        
        pos = pos + direntp->len;
    }
    
    int close = system_call(SYS_CLOSE, filedesc);
    
    if(debug_mode)
    {
        system_call(SYS_WRITE, STDERR, "system_call:\nID: 6, return code: ", 33);
        str = itoa(close);
        system_call(SYS_WRITE, STDERR, str, strlen(str));
        system_call(SYS_WRITE, STDERR, "\n", 1);
    }
    
    return(0);
}