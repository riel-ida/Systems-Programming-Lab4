#include "util.h"

#define SYS_OPEN 5
#define SYS_CLOSE 6
#define SYS_WRITE 4
#define SYS_EXIT 1
#define SYS_LSEEK 19
#define STDOUT 1
#define STDERR 2


void patch(char *file_name, char *x_name) {
    
    int topatch = system_call(SYS_OPEN, file_name, 2, 0777);
    if(topatch == -1)
    {
        system_call(SYS_WRITE, STDERR,"Error opening file. exit program.\n", 34);
        system_call(SYS_EXIT, 0x55);
    }
    
    if(system_call(SYS_LSEEK, topatch, 0x291, 0) == 0)
    {
        system_call(SYS_WRITE, STDERR,"Error searching in file. exit program.\n", 36);
        system_call(SYS_EXIT, 0x55);
    }
    system_call(SYS_WRITE,topatch, x_name, strlen(x_name));
    
    if(strlen(x_name) != 5)
    {
        char* fix = ".\n\0";
        system_call(SYS_WRITE, topatch, fix, 3);
    }
    
    system_call(SYS_CLOSE, topatch);
}


int main (int argc , char* argv[], char* envp[])
{
    if(argc < 3)
    {
        system_call(SYS_WRITE, STDERR,"Error opening file. exit program.\n", 34);
        system_call(SYS_EXIT, 0x55);
    }
    
    char *file_name = argv[1];
    char *x_name = argv[2];
    patch(file_name, x_name);
    
    return 0;
}

