#include "util.h"

#define SYS_OPEN 5
#define SYS_CLOSE 6
#define SYS_READ 3
#define SYS_WRITE 4
#define SYS_EXIT 1
#define SYS_LSEEK 19
#define STDIN 0
#define STDOUT 1
#define STDERR 2
#define BUFFLN 128

int main(int argc, char **argv) {
    
    int debug_mode = 0, i, j;
    char inbuffer[BUFFLN];
    char* str;

    for(i=1; i<argc; i++)
    {
        if(argv[i][1] == 'D')
        {
            debug_mode = 1;
        }  
    }

    while(1) 
    {
        for(i=0; i < BUFFLN; i++)
        {
            int in = system_call(SYS_READ, STDIN, &inbuffer[i], 1);
            
            if(debug_mode)
            {
                system_call(SYS_WRITE, STDERR, "system_call: ID = 3, return code = ", 35);
                str = itoa(in);
                system_call(SYS_WRITE, STDERR, str, strlen(str));
                system_call(SYS_WRITE, STDERR, "\n", 1);
            }
        
            if(in == 1) {
                
                if(inbuffer[i] == 10)
                {
                    int out = system_call(SYS_WRITE, STDOUT, inbuffer, strlen(inbuffer));
                    if(debug_mode)
                    {
                        system_call(SYS_WRITE, STDERR, "system_call: ID = 4, return code = ", 35);
                        str = itoa(out);
                        system_call(SYS_WRITE, STDERR, str, strlen(str));
                        system_call(SYS_WRITE, STDERR, "\n", 1);
                    }
                    break;
                }
                
                if(inbuffer[i] > 64 && inbuffer[i] < 91) 
                {
                    inbuffer[i] += 32;
                }

            }
        
            if(in != 1) {
                system_call(SYS_EXIT, 0x55);
            }
        }
    }
    
    return(0);
}