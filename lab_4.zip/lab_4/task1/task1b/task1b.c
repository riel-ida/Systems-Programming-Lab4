#include "util.h"

#define SYS_OPEN 5
#define SYS_CLOSE 6
#define SYS_READ 3
#define SYS_WRITE 4
#define SYS_EXIT 1
#define SYS_LSEEK 19
#define STDIN 0
#define STDOUT 1
#define STDERR 2
#define BUFFLN 128

int main(int argc, char **argv) {
    
    int debug_mode = 0, inFile_mode = 0, outFile_mode = 0, inFile_name = 0, outFile_name = 0;
    int inFile = 0, outFile = 1;
    int i;
    char inbuffer[BUFFLN];
    char* str;

    for(i=1; i<argc; i++)
    {
        if(argv[i][1] == 'D')
        {
            debug_mode = 1;
        }  
        
        else if(argv[i][1] == 'i')
        {
            inFile_mode = 1;
            inFile_name = i;
        }
        
        else if(argv[i][1] == 'o')
        {
            outFile_mode = 1;
            outFile_name = i;
        } 
    }
    
    if(inFile_mode)
    {
        char* in_name = argv[inFile_name] + 2;
        inFile = system_call(SYS_OPEN, in_name, 0, 0777);
        if(inFile == -1)
        {
            system_call(SYS_WRITE, STDERR,"Error opening file. exit program.\n", 34);
            system_call(SYS_EXIT, 0x55);
        }
        
        if(debug_mode)
        {
            system_call(SYS_WRITE, STDERR, "system_call: ID = 5, return code = ", 35);
            str = itoa(inFile);
            system_call(SYS_WRITE, STDERR, str, strlen(str));
            system_call(SYS_WRITE, STDERR, "\n", 1);
        }
    }
    
    if(outFile_mode)
    {
        char* out_name = argv[outFile_name] + 2;
        outFile = system_call(SYS_OPEN, out_name, 64+1, 0777);
        if(outFile == -1)
        {
            system_call(SYS_WRITE, STDERR,"Error opening file. exit program.\n", 34);
            system_call(SYS_EXIT, 0x55);
        }
        
        if(debug_mode)
        {
            system_call(SYS_WRITE, STDERR, "system_call: ID = 5, return code = ", 35);
            str = itoa(outFile);
            system_call(SYS_WRITE, STDERR, str, strlen(str));
            system_call(SYS_WRITE, STDERR, "\n", 1);
        }
    }
    
    while(1) 
    {
        for(i=0; i < BUFFLN; i++)
        {
            int in = system_call(SYS_READ, inFile, &inbuffer[i], 1);
            
            if(debug_mode)
            {
                system_call(SYS_WRITE, STDERR, "system_call: ID = 3, return code = ", 35);
                str = itoa(in);
                system_call(SYS_WRITE, STDERR, str, strlen(str));
                system_call(SYS_WRITE, STDERR, "\n", 1);
            }
        
            if(in == 1) 
            {
                if(inbuffer[i] == 10)
                {
                    int out = system_call(SYS_WRITE, outFile, inbuffer, strlen(inbuffer));
                    
                    if(debug_mode)
                    {
                        system_call(SYS_WRITE, STDERR, "system_call: ID = 4, return code = ", 35);
                        str = itoa(out);
                        system_call(SYS_WRITE, STDERR, str, strlen(str));
                        system_call(SYS_WRITE, STDERR, "\n", 1);
                    }
        
                    break;
                }
                
                if(inbuffer[i] > 64 && inbuffer[i] < 91) 
                {
                    inbuffer[i] += 32;
                }

            }
            
            if(in == -1)
            {
                system_call(SYS_WRITE, STDERR,"Error reading from file. exit program.\n", 39);
                system_call(SYS_EXIT, 0x55);
            }
        
            else 
            {
                if(inFile_mode)
                {
                    int inClose = system_call(SYS_CLOSE, inFile);
                    
                    if(debug_mode)
                    {
                        system_call(SYS_WRITE, STDERR, "system_call: ID = 6, return code = ", 35);
                        str = itoa(inClose);
                        system_call(SYS_WRITE, STDERR, str, strlen(str));
                        system_call(SYS_WRITE, STDERR, "\n", 1);
                    }
                }
                
                if(outFile_mode)
                {
                    int outClose = system_call(SYS_CLOSE, outFile);
                    
                    if(debug_mode)
                    {
                        system_call(SYS_WRITE, STDERR, "system_call: ID = 6, return code = ", 35);
                        str = itoa(outClose);
                        system_call(SYS_WRITE, STDERR, str, strlen(str));
                        system_call(SYS_WRITE, STDERR, "\n", 1);
                    }
                }
                
                system_call(SYS_EXIT, 0);
            }
        }
    }
    
    return(0);
    
}